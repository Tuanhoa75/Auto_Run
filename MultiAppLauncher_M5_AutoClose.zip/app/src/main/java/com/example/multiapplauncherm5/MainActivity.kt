package com.example.multiapplauncherm5

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var apps: List<Pair<String, Boolean>>
    private var delay: Long = 3000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val list = mutableListOf<Pair<String, Boolean>>()

        for (i in 1..5) {
            val pkg = prefs.getString("App$i", null)
            val play = prefs.getBoolean("Play$i", false)
            if (pkg != null) list.add(pkg to play)
        }

        delay = prefs.getLong("Delay", 3000)

        if (list.isEmpty()) {
            startActivity(Intent(this, ConfigActivity::class.java))
            finish()
            return
        }

        apps = list
        launchAppsSequentially(0)
    }

    private fun launchAppsSequentially(index: Int) {
        if (index >= apps.size) {
            finishAffinity() // Tự động thoát app sau khi hoàn tất
            return
        }

        val (pkg, sendPlay) = apps[index]
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent)

        Handler(Looper.getMainLooper()).postDelayed({
            if (sendPlay) sendMediaPlayKey()
            Handler(Looper.getMainLooper()).postDelayed({
                launchAppsSequentially(index + 1)
            }, delay)
        }, delay)
    }

    private fun sendMediaPlayKey() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
        val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
        am.dispatchMediaKeyEvent(down)
        am.dispatchMediaKeyEvent(up)
    }
}
