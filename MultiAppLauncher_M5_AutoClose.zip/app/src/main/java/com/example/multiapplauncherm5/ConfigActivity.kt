package com.example.multiapplauncherm5

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ConfigActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        val labels = apps.map { it.loadLabel(pm).toString() }
        val packages = apps.map { it.packageName }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        val spinners = listOf<Spinner>(
            findViewById(R.id.spinnerApp1),
            findViewById(R.id.spinnerApp2),
            findViewById(R.id.spinnerApp3),
            findViewById(R.id.spinnerApp4),
            findViewById(R.id.spinnerApp5)
        )
        val checks = listOf<CheckBox>(
            findViewById(R.id.checkPlay1),
            findViewById(R.id.checkPlay2),
            findViewById(R.id.checkPlay3),
            findViewById(R.id.checkPlay4),
            findViewById(R.id.checkPlay5)
        )

        spinners.forEach { it.adapter = adapter }
        val inputDelay = findViewById<EditText>(R.id.inputDelay)

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE).edit()
            for (i in 0 until 5) {
                prefs.putString("App${i + 1}", packages[spinners[i].selectedItemPosition])
                prefs.putBoolean("Play${i + 1}", checks[i].isChecked)
            }

            val delay = inputDelay.text.toString().toLongOrNull() ?: 3000L
            prefs.putLong("Delay", delay)
            prefs.apply()

            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
